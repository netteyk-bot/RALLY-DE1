Peter: Working on DE2-115 for Quartus 16.1 in lab
Peter: Working on DE1-SoC for Quartus 23.1 in lab

This basically executes some sequential code that is linked to the vga_driver.v module.

This is a simple start point for VGA writing.